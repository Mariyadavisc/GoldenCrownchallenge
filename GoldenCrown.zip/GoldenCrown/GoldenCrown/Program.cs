﻿using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            String path = args[0];
            if (File.Exists(path))
            {
                string[] lines = File.ReadAllLines(path);
                if (lines.Count() > 0)
                {
                    var kingdom = FindKingdom(lines);
                }
            }
        }

        private static string FindKingdom(string[] lines)
        {
            var alice = "SPACE ";
            foreach (var x in lines)
            {
                var decrypted = "";
                if (x.Split(null)[0].Count() == 3)
                {
                    if (x.Split(null)[0].ToUpper() == "AIR")
                    {
                        foreach (var y in x.Split(null)[1].ToUpper())
                        {
                            if ((int)y - 3 < 65)
                            {
                                var dif = 65 - ((int)y - 3);
                                decrypted += (char)(65 - dif + 26);
                            }
                            else
                            {
                                decrypted += (char)((int)y - 3);
                            }
                        }
                        int cnt1 = 0, cnt2 = 0, cnt3 = 0;
                        foreach (var i in decrypted)
                        {
                            if (i == 'O')
                            {
                                cnt1 += 1;
                            }
                            else if (i == 'W')
                            {
                                cnt2 += 1;
                            }
                            else if (i == 'L')
                            {
                                cnt3 += 1;
                            }
                        }

                        if (cnt1 > 0 && cnt2 > 0 && cnt3 > 0)
                        {
                            alice += "AIR ";
                        }
                    }
                    else if (x.Split(null)[0].ToUpper() == "ICE")
                    {
                        foreach (var y in x.Split(null)[1].ToUpper())
                        {
                            if ((int)y - 7 < 65)
                            {
                                var dif = 65 - ((int)y - 7);
                                decrypted += (char)(65 - dif + 26);
                            }
                            else
                            {
                                decrypted += (char)((int)y - 7);
                            }
                        }
                        int cnt1 = 0, cnt2 = 0, cnt3 = 0, cnt4 = 0, cnt5 = 0;
                        foreach (var i in decrypted)
                        {
                            if (i == 'M')
                            {
                                cnt1 += 1;
                            }
                            else if (i == 'A')
                            {
                                cnt2 += 1;
                            }
                            else if (i == 'O')
                            {
                                cnt3 += 1;
                            }
                            else if (i == 'T')
                            {
                                cnt4 += 1;
                            }
                            else if (i == 'H')
                            {
                                cnt5 += 1;
                            }
                        }

                        if (cnt1 > 2 && cnt2 > 0 && cnt3 > 0 && cnt4 > 0 && cnt5 > 0)
                        {
                            alice += "ICE ";
                        }
                    }
                }
                else if (x.Split(null)[0].Count() == 4)
                {
                    if (x.Split(null)[0].ToUpper() == "LAND")
                    {
                        foreach (var y in x.Split(null)[1].ToUpper())
                        {
                            if ((int)y - 5 < 65)
                            {
                                var dif = 65 - ((int)y - 5);
                                decrypted += (char)(65 - dif + 26);
                            }
                            else
                            {
                                decrypted += (char)((int)y - 5);
                            }
                        }
                        int cnt1 = 0, cnt2 = 0, cnt3 = 0, cnt4 = 0;
                        foreach (var i in decrypted)
                        {
                            if (i == 'P')
                            {
                                cnt1 += 1;
                            }
                            else if (i == 'A')
                            {
                                cnt2 += 1;
                            }
                            else if (i == 'N')
                            {
                                cnt3 += 1;
                            }
                            else if (i == 'D')
                            {
                                cnt4 += 1;
                            }
                        }

                        if (cnt1 > 0 && cnt2 > 1 && cnt3 > 0 && cnt4 > 0)
                        {
                            alice += "LAND ";
                        }
                    }
                    else if (x.Split(null)[0].ToUpper() == "FIRE")
                    {
                        foreach (var y in x.Split(null)[1].ToUpper())
                        {
                            if ((int)y - 6 < 65)
                            {
                                var dif = 65 - ((int)y - 6);
                                decrypted += (char)(65 - dif + 26);
                            }
                            else
                            {
                                decrypted += (char)((int)y - 6);
                            }
                        }
                        int cnt1 = 0, cnt2 = 0, cnt3 = 0, cnt4 = 0, cnt5 = 0, cnt6 = 0;
                        foreach (var i in decrypted)
                        {
                            if (i == 'D')
                            {
                                cnt1 += 1;
                            }
                            else if (i == 'R')
                            {
                                cnt2 += 1;
                            }
                            else if (i == 'A')
                            {
                                cnt3 += 1;
                            }
                            else if (i == 'G')
                            {
                                cnt4 += 1;
                            }
                            else if (i == 'O')
                            {
                                cnt5 += 1;
                            }
                            else if (i == 'N')
                            {
                                cnt6 += 1;
                            }
                        }

                        if (cnt1 > 0 && cnt2 > 0 && cnt3 > 0 && cnt4 > 0 && cnt5 > 0 && cnt6 > 0)
                        {
                            alice += "FIRE ";
                        }
                    }
                }
                else if (x.Split(null)[0].Count() == 5)
                {
                    if (x.Split(null)[0].ToUpper() == "WATER")
                    {
                        foreach (var y in x.Split(null)[1].ToUpper())
                        {
                            if ((int)y - 7 < 65)
                            {
                                var dif = 65 - ((int)y - 7);
                                decrypted += (char)(65 - dif + 26);
                            }
                            else
                            {
                                decrypted += (char)((int)y - 7);
                            }
                        }
                        int cnt1 = 0, cnt2 = 0, cnt3 = 0, cnt4 = 0, cnt5 = 0, cnt6 = 0, cnt7 = 0;
                        foreach (var i in decrypted)
                        {
                            if (i == 'O')
                            {
                                cnt1 += 1;
                            }
                            else if (i == 'C')
                            {
                                cnt2 += 1;
                            }
                            else if (i == 'T')
                            {
                                cnt3 += 1;
                            }
                            else if (i == 'O')
                            {
                                cnt4 += 1;
                            }
                            else if (i == 'P')
                            {
                                cnt5 += 1;
                            }
                            else if (i == 'U')
                            {
                                cnt6 += 1;
                            }
                            else if (i == 'S')
                            {
                                cnt7 += 1;
                            }
                        }

                        if (cnt1 > 0 && cnt2 > 1 && cnt3 > 0 && cnt4 > 0 && cnt5 > 1 && cnt6 > 0)
                        {
                            alice += "WATER ";
                        }
                    }
                }
            }
            Console.WriteLine(alice);
            return "a";
        }
    }
}
